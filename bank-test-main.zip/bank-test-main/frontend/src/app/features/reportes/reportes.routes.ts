import { Routes } from '@angular/router';
import { ReportesPageComponent } from './reportes-page.component';

export const REPORTES_ROUTES: Routes = [
  { path: '', component: ReportesPageComponent },
];
