package com.bank.api.entity;

public enum TipoCuenta {
    AHORROS,
    CORRIENTE
}
