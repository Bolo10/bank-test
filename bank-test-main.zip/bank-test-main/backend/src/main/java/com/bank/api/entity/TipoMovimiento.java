package com.bank.api.entity;

//HACEMOS ENUM PARA QUE EN LAS PETICIONES NO ENVIEN CUALQUIER TEXTO
public enum TipoMovimiento {
    RETIRO,
    DEPOSITO
}
